package com.example.mosque.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mosque.R
import com.example.mosque.model.AssetModel

class AssetsAdapter(val assetItems: MutableList<AssetModel>) : RecyclerView.Adapter<AssetsAdapter.AssetsViewHolder>(){

    val context : Context? = null

    fun updateAssetItems(newAssetItem: List<AssetModel>){
        assetItems.clear()
        assetItems.addAll(newAssetItem)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int) : AssetsViewHolder {

    }

    override fun getItemCount()= assetItems.size


    override fun onBindViewHolder(holder: AssetsViewHolder, position: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    class AssetsViewHolder() {

    }


}