package com.example.mosque.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class AssetModel (

        @SerializedName("id")
        @Expose
        val id: Int,
        @SerializedName("mosque_id")
        @Expose
        val mosqueassetId: String,
        @SerializedName("code")
        @Expose
        val mosqueCode: String,
        @SerializedName("name")
        @Expose
        val assetName: String,
        @SerializedName("type")
        @Expose
        val assetType: String,
        @SerializedName("category")
        @Expose
        val assetCategory: String,
        @SerializedName("condition")
        @Expose
        val assetCondition: String,
        @SerializedName("status")
        @Expose
        val assetStatus: String,
        @SerializedName("image_asset")
        @Expose
        val assetImage: String,
        @SerializedName("desc")
        @Expose
        val assetDesc: String
)
