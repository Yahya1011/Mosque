package com.example.mosque.model

data class MainNav(
    val nav_icon: Int,
    val nav_name : String)