package com.example.mosque.model

import java.io.Serializable

data class LocationModel(val latitude: Double, val longitude: Double): Serializable